# Spending Tracker

**NOTA** Para poder hacer funcionar el correo electrónico, es necesario que accedas a config/recovery.php y cambies la información solicitada. Te agrego un video en donde lo configuro. [Video Youtube](https://youtu.be/YKWCggi9WVw)

## Tabla de Contenido
***
- [Spending Tracker](#spending-tracker)
  - [Tabla de Contenido](#tabla-de-contenido)
  - [Descripción](#descripción)
  - [Instalación](#instalación)
  - [Uso](#uso)
  - [Tecnologías ocupadas](#tecnologías-ocupadas)
  - [Licencia](#licencia)


## Descripción
***
**Spending Tracker** es un proyecto para la gestión de gastos personales. El objetivo es que diariamente se lleven a cabo registros de nuestros gastos, así como de nuestros ingresos, lo que permitirá obtener balances y resultados de la diferencia entre cada uno de ellos.
## Instalación
***
Para poder instalar **Spending Tracker** solo es necesario contar con un servidor MySQL y un servidor Web
## Uso
***
Para poder usar **Speding Tracker** de manera local es necesario tener instalado:
- XAMPP
- VSCode
- Github Desktop
## Tecnologías ocupadas
***
1. HTML
2. CSS
3. Bootstrap
4. MySQL
5. PHP
## Licencia
***

The MIT License (MIT)
Copyright (c) 2022
